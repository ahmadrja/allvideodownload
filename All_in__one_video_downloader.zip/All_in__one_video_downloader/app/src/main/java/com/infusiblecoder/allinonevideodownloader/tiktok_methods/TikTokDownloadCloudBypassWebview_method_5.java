/*
 * *
 *  * Created by Syed Usama Ahmad on 3/17/23, 11:37 PM
 *  * Copyright (c) 2023 . All rights reserved.
 *  * Last modified 3/17/23, 10:26 PM
 *
 */

package com.infusiblecoder.allinonevideodownloader.tiktok_methods;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.infusiblecoder.allinonevideodownloader.R;
import com.infusiblecoder.allinonevideodownloader.databinding.ActivityTikTokDownloadWebviewBinding;
import com.infusiblecoder.allinonevideodownloader.utils.DownloadFileMain;
import com.infusiblecoder.allinonevideodownloader.utils.iUtils;
import com.libs.zhkrb.cloudflare_scrape_webview.CfCallback;
import com.libs.zhkrb.cloudflare_scrape_webview.Cloudflare;

import java.net.HttpCookie;
import java.util.List;

public class TikTokDownloadCloudBypassWebview_method_5 extends AppCompatActivity {

    private static final String TIKTOK_URL = "https://www.tiktok.com/";
    private static final String DOWNLOAD_URL = "https://tiktokio.com/";
    private static final String TAG = "TikTokWebview";
    private static final int FILE_UPLOAD_CODE = 1001;
    private static ValueCallback<Uri[]> mUploadMessageArr;
    private ActivityTikTokDownloadWebviewBinding binding;
    private ProgressDialog progressDialog;
    private boolean isDownloadStarted = false;
    private String videoUrl = "";
    private Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        binding = ActivityTikTokDownloadWebviewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.tool12);

        videoUrl = getIntent().getStringExtra("myvidurl");
        initHandler();
        setupProgressDialog();
        setupWebView();
        setupClickListeners();
    }

    private void setupProgressDialog() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage(getString(R.string.nodeifittakeslonger));
        progressDialog.show();
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void setupWebView() {
        WebSettings webSettings = getWebSettings();

        binding.webViewscan.setWebViewClient(new MyBrowser());
        binding.webViewscan.setWebChromeClient(new CustomWebChromeClient());
        binding.webViewscan.setDownloadListener(this::startDownload);


        Cloudflare cf = new Cloudflare(this, DOWNLOAD_URL);
        //   cf.setUser_agent("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.169 Safari/537.36");
        cf.setUser_agent(webSettings.getUserAgentString());
        cf.setCfCallback(new CfCallback() {
            @Override
            public void onSuccess(List<HttpCookie> cookieList, boolean hasNewUrl, String newUrl) {
                binding.webViewscan.loadUrl(newUrl);
            }

            @Override
            public void onFail(int code, String msg) {
                binding.webViewscan.loadUrl(DOWNLOAD_URL);
            }
        });
        cf.getCookies();


    }


    @NonNull
    private WebSettings getWebSettings() {
        WebSettings webSettings = binding.webViewscan.getSettings();
        webSettings.setJavaScriptEnabled(true);
        webSettings.setDomStorageEnabled(true);
        webSettings.setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webSettings.setAllowFileAccess(true);
        webSettings.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        webSettings.setLoadsImagesAutomatically(true);
        webSettings.setBlockNetworkImage(false);
        webSettings.setLoadWithOverviewMode(true);
        webSettings.setUseWideViewPort(true);
        return webSettings;
    }

    private void setupClickListeners() {
        binding.opentiktok.setOnClickListener(v -> openTikTok());
    }

    private void openTikTok() {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(TIKTOK_URL));
            intent.setPackage("com.zhiliaoapp.musically");
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            iUtils.ShowToast(this, "TikTok not installed");
        }
    }

    private void startDownload(String url, String userAgent, String contentDisposition, String mimetype, long contentLength) {
        String fileName = "Tiktok_video_" + System.currentTimeMillis();
        DownloadFileMain.startDownloading(this, url, fileName, ".mp4");
    }

    @SuppressLint("HandlerLeak")
    private void initHandler() {
        handler = new Handler();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_UPLOAD_CODE && mUploadMessageArr != null) {
            mUploadMessageArr.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            mUploadMessageArr = null;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (binding.webViewscan.canGoBack()) {
            binding.webViewscan.goBack();
        } else {
            finishAndDismiss();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        clearWebViewCache();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        clearWebViewCache();
    }

    private void clearWebViewCache() {
        binding.webViewscan.clearCache(true);
    }

    private void finishAndDismiss() {
        if (progressDialog != null && progressDialog.isShowing()) {
            progressDialog.dismiss();
        }
        finish();
    }

    private class CustomWebChromeClient extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView view, int progress) {
            binding.progressBar.setVisibility(progress < 100 ? View.VISIBLE : View.GONE);
            binding.progressBar.setProgress(progress);
        }

        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            request.grant(request.getResources());
        }
    }

    private class MyBrowser extends WebViewClient {
        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            binding.progressBar.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView view, String url) {
            binding.progressBar.setVisibility(View.GONE);
            injectJavaScript(view);
            startDataCheck(view);
        }

        private void injectJavaScript(WebView view) {
            String jsScript = "javascript:(function() { " +
                    "document.getElementById('tiktok-url-input').value = '" + videoUrl + "'; " +
                    "setTimeout(function() { " +
                    "    document.getElementById('search-btn').click(); " +
                    "}, 300);" +
                    "})();";
            view.evaluateJavascript(jsScript, result -> Log.e(TAG, "JS executed: " + result));
        }


        private void startDataCheck(WebView view) {
            handler = new Handler();
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    view.evaluateJavascript(
                            "(function() {" +
                                    "    var anchors = document.getElementsByTagName('a');" +
                                    "    var urls = [];" +
                                    "    for (var i = 0; i < anchors.length; i++) {" +
                                    "        var href = anchors[i].getAttribute('href');" +
                                    "        if (href && href.includes('dl.tiktokio.com')) {" +
                                    "            urls.push(href);" +
                                    "        }" +
                                    "    }" +
                                    "    return urls.length > 0 ? urls[0] : null;" +
                                    "})();",
                            obj -> {
                                Log.e(TAG, "JS executed startDataCheck: " + obj);

                                if (obj != null && obj.contains("http") && !isDownloadStarted) {
                                    // Remove the callback to stop further checks
                                    handler.removeCallbacks(this);

                                    // Start the download with the first matching URL
                                    String fileName = "Tiktok_video_" + System.currentTimeMillis();
                                    DownloadFileMain.startDownloading(TikTokDownloadCloudBypassWebview_method_5.this, obj, fileName, ".mp4");
                                    isDownloadStarted = true;
                                    finishAndDismiss();
                                } else {
                                    // If not ready, keep checking every 2 seconds
                                    handler.postDelayed(this, 2000);
                                }
                            });
                }
            }, 2000);
        }


    }
}

