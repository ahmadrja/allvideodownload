package com.infusiblecoder.allinonevideodownloader.interfaces;

public interface EncryptionCallbackNew {
    void onDataEncrypted(String encryptedData);

}
