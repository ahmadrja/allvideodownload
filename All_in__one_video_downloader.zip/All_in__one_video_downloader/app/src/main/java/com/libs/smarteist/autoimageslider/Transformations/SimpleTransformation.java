package com.libs.smarteist.autoimageslider.Transformations;

import android.view.View;

import com.libs.smarteist.autoimageslider.SliderPager;

public class SimpleTransformation implements SliderPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}