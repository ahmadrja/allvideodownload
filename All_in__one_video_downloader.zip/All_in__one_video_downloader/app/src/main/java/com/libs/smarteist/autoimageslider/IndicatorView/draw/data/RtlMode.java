package com.libs.smarteist.autoimageslider.IndicatorView.draw.data;

public enum RtlMode {On, Off, Auto}